# MPTDC Final Typical Genus Readiness

- Flow: `MPTDC_GENUS_TYPICAL`
- Mode: `MPTDC_TYPICAL_TIMING_CLOSURE`
- Package label: `TYPICAL_ONLY_TAPEOUT_PACKAGE`
- Signoff boundary: `TYPICAL_ONLY_NOT_MMMC`
- Legacy trace: `O13_ABS5_PD_Q1_EXCEPTION_EXACT_MATCH`
- Run ID: `final_typical_mptdc_genus_20260610_124954`
- Result directory: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954`
- Genus exit code: `1`
- Final decision: `GENUS_TYPICAL_REVIEW_REQUIRED`

## Required Checks

| Check | Expected | Actual | Status |
|---|---:|---:|---|
| RO_tune4 count | `2` | `2` | PASS |
| mptdc_osc_stub count | `0` | `0` | PASS |
| raw RO clocks found | `16` | `16` | PASS |
| buffer phase clocks found | `16` | `16` | PASS |
| clk_sys async to buffer phase clocks | `YES` | `YES` | PASS |
| PD Vernier endpoints | `64` | `64` | PASS |
| PD Vernier sources | `8` | `8` | PASS |
| PD Vernier exception applied | `YES` | `YES` | PASS |
| PD Vernier overmatch | `NO` | `NO` | PASS |
| PD Vernier undermatch | `NO` | `NO` | PASS |
| UNKNOWN_REVIEW_REQUIRED | `0` | `0` | PASS |
| SDC command failures | `0` | `0` | PASS |
| max capacitance violations | `0` | `0` | PASS |
| max fanout violations | `0` | `0` | PASS |

## Timing And DRV

- Real timed WNS ps: `1.0`
- Real timed TNS ps: `0.0`
- Worst real path family: `FAST_TAG_TO_PD_TS`
- Max transition violations: `1015`

## Classification Summary

# Timing Path Classification Summary

- Parsed paths: 342
- UNKNOWN_REVIEW_REQUIRED paths: 0

## WNS/TNS By Class

| Classification | Paths | WNS ps | TNS ps |
|---|---:|---:|---:|
| `OSC_FAST_REAL` | 242 | -4.0 | -178.0 |
| `CLK_SYS_REAL` | 100 | 27.0 | 0.0 |

## WNS/TNS By Family

| Family | Paths | WNS ps | TNS ps |
|---|---:|---:|---:|
| `FAST_TAG_TO_PD_TS` | 240 | -4.0 | -174.0 |
| `LOCAL_FAST_TAG_SELF` | 2 | -2.0 | -4.0 |
| `CLK_SYS_OTHER` | 26 | 27.0 | 0.0 |
| `CLK_SYS_WATCHDOG` | 16 | 62.0 | 0.0 |
| `CLK_SYS_DRAIN` | 58 | 156.0 | 0.0 |

## Top Unknown Paths

- None

## Interpretation

Do not call closure yet. Review the failing criteria and the worst real path family before running Innovus implementation.
