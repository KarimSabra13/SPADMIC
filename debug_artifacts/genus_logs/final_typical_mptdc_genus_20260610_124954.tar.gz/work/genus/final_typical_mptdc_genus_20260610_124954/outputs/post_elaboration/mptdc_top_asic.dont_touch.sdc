set_dont_use [get_lib_cells LGCNHDX0]
set_dont_use [get_lib_cells LGCNHDX1]
set_dont_use [get_lib_cells LGCNHDX2]
set_dont_use [get_lib_cells LGCNHDX4]
set_dont_use [get_lib_cells LGCPHDX0]
set_dont_use [get_lib_cells LGCPHDX1]
set_dont_use [get_lib_cells LGCPHDX2]
set_dont_use [get_lib_cells LGCPHDX4]
set_dont_use [get_lib_cells LSGCNHDX0]
set_dont_use [get_lib_cells LSGCNHDX1]
set_dont_use [get_lib_cells LSGCNHDX2]
set_dont_use [get_lib_cells LSGCNHDX4]
set_dont_use [get_lib_cells LSGCPHDX0]
set_dont_use [get_lib_cells LSGCPHDX1]
set_dont_use [get_lib_cells LSGCPHDX2]
set_dont_use [get_lib_cells LSGCPHDX4]
set_dont_use [get_lib_cells LSOGCNHDX0]
set_dont_use [get_lib_cells LSOGCNHDX1]
set_dont_use [get_lib_cells LSOGCNHDX2]
set_dont_use [get_lib_cells LSOGCNHDX4]
set_dont_use [get_lib_cells LSOGCPHDX0]
set_dont_use [get_lib_cells LSOGCPHDX1]
set_dont_use [get_lib_cells LSOGCPHDX2]
set_dont_use [get_lib_cells LSOGCPHDX4]
set_dont_use [get_lib_cells SDFFQHDX0]
set_dont_use [get_lib_cells SDFFQHDX1]
set_dont_use [get_lib_cells SDFFQHDX2]
set_dont_use [get_lib_cells SDFFQHDX4]
set_dont_use [get_lib_cells SDFFRQHDX0]
set_dont_use [get_lib_cells SDFFRQHDX1]
set_dont_use [get_lib_cells SDFFRQHDX2]
set_dont_use [get_lib_cells SDFFRQHDX4]
set_dont_use [get_lib_cells SDFFSQHDX0]
set_dont_use [get_lib_cells SDFFSQHDX1]
set_dont_use [get_lib_cells SDFFSQHDX2]
set_dont_use [get_lib_cells SDFFSQHDX4]
set_dont_use [get_lib_cells SDFRQHDX0]
set_dont_use [get_lib_cells SDFRQHDX1]
set_dont_use [get_lib_cells SDFRQHDX2]
set_dont_use [get_lib_cells SDFRQHDX4]
set_dont_use [get_lib_cells SDFRRQHDX0]
set_dont_use [get_lib_cells SDFRRQHDX1]
set_dont_use [get_lib_cells SDFRRQHDX2]
set_dont_use [get_lib_cells SDFRRQHDX4]
set_dont_use [get_lib_cells SDFRSQHDX0]
set_dont_use [get_lib_cells SDFRSQHDX1]
set_dont_use [get_lib_cells SDFRSQHDX2]
set_dont_use [get_lib_cells SDFRSQHDX4]
set_dont_use [get_lib_cells STEHDX0]
set_dont_use [get_lib_cells STEHDX1]
set_dont_use [get_lib_cells STEHDX2]
set_dont_use [get_lib_cells STEHDX4]
set_dont_use [get_lib_cells SIGNALHOLDDHD]
set_dont_use [get_lib_cells FEED1HD]
set_dont_use [get_lib_cells FEED2HD]
set_dont_use [get_lib_cells FEED3HD]
set_dont_use [get_lib_cells FEED5HD]
set_dont_use [get_lib_cells FEED7HD]
set_dont_use [get_lib_cells FEED10HD]
set_dont_use [get_lib_cells FEED15HD]
set_dont_use [get_lib_cells FEED25HD]
set_dont_use [get_lib_cells DECAP3HD]
set_dont_use [get_lib_cells DECAP5HD]
set_dont_use [get_lib_cells DECAP7HD]
set_dont_use [get_lib_cells DECAP10HD]
set_dont_use [get_lib_cells DECAP15HD]
set_dont_use [get_lib_cells DECAP25HD]
set_dont_use [get_lib_cells FCNE2HD]
set_dont_use [get_lib_cells FCNE3HD]
set_dont_use [get_lib_cells FCNE4HD]
set_dont_use [get_lib_cells FCNE5HD]
set_dont_use [get_lib_cells FCNE6HD]
set_dont_use [get_lib_cells FCNE7HD]
set_dont_use [get_lib_cells FCNE8HD]
set_dont_use [get_lib_cells FCNE9HD]
set_dont_use [get_lib_cells FCNE10HD]
set_dont_use [get_lib_cells FCNE11HD]
set_dont_use [get_lib_cells FCNE12HD]
set_dont_use [get_lib_cells FCNE13HD]
set_dont_use [get_lib_cells FCNE14HD]
set_dont_use [get_lib_cells FCNE15HD]
set_dont_use [get_lib_cells FCNE16HD]
set_dont_use [get_lib_cells FCNE17HD]
set_dont_use [get_lib_cells FCNE18HD]
set_dont_use [get_lib_cells FCNE19HD]
set_dont_use [get_lib_cells FCNE20HD]
set_dont_use [get_lib_cells FCNE21HD]
set_dont_use [get_lib_cells FCNE22HD]
set_dont_use [get_lib_cells FCNE23HD]
set_dont_use [get_lib_cells FCNE24HD]
set_dont_use [get_lib_cells FCNE25HD]
set_dont_use [get_lib_cells FCNE26HD]
set_dont_use [get_lib_cells FCNE27HD]
set_dont_use [get_lib_cells FCNE28HD]
set_dont_use [get_lib_cells FCNE29HD]
set_dont_use [get_lib_cells FCNE30HD]
set_dont_use [get_lib_cells FCNE31HD]
set_dont_use [get_lib_cells FCNE32HD]
set_dont_use [get_lib_cells FCNED5HD]
set_dont_use [get_lib_cells FCNED6HD]
set_dont_use [get_lib_cells FCNED7HD]
set_dont_use [get_lib_cells FCNED8HD]
set_dont_use [get_lib_cells FCNED9HD]
set_dont_use [get_lib_cells FCNED10HD]
set_dont_use [get_lib_cells FCNED11HD]
set_dont_use [get_lib_cells FCNED12HD]
set_dont_use [get_lib_cells FCNED13HD]
set_dont_use [get_lib_cells FCNED14HD]
set_dont_use [get_lib_cells FCNED15HD]
set_dont_use [get_lib_cells FCNED16HD]
set_dont_use [get_lib_cells FCNED17HD]
set_dont_use [get_lib_cells FCNED18HD]
set_dont_use [get_lib_cells FCNED19HD]
set_dont_use [get_lib_cells FCNED20HD]
set_dont_use [get_lib_cells FCNED21HD]
set_dont_use [get_lib_cells FCNED22HD]
set_dont_use [get_lib_cells FCNED23HD]
set_dont_use [get_lib_cells FCNED24HD]
set_dont_use [get_lib_cells FCNED25HD]
set_dont_use [get_lib_cells FCNED26HD]
set_dont_use [get_lib_cells FCNED27HD]
set_dont_use [get_lib_cells FCNED28HD]
set_dont_use [get_lib_cells FCNED29HD]
set_dont_use [get_lib_cells FCNED30HD]
set_dont_use [get_lib_cells FCNED31HD]
set_dont_use [get_lib_cells FCNED32HD]
set_dont_use [get_lib_cells ANTENNACELLN2HD]
set_dont_use [get_lib_cells ANTENNACELLNP2HD]
set_dont_use [get_lib_cells ANTENNACELLP2HD]
set_dont_use [get_lib_cells BUSSHDX0]
set_dont_use [get_lib_cells BUSSHDX1]
set_dont_touch [get_designs mptdc_phase_buffer_bank] ; # true
set_dont_touch [get_cells u_core/u_osc_slow/u_ro_tune4] ; # size_ok
set_dont_touch [get_cells u_core/u_osc_fast/u_ro_tune4] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[0].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[1].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[2].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[3].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[4].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[5].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[6].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[7].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[0].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[1].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[2].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[3].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[4].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[5].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[6].u_drv}] ; # size_ok
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[7].u_drv}] ; # size_ok
set_dont_touch [get_cells u_core/u_osc_slow/u_ro_tune4] ; # break_timing_path/ideal_network
set_dont_touch [get_cells u_core/u_osc_fast/u_ro_tune4] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[0].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[1].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[2].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[3].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[4].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[5].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[6].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_slow/gen_phase_buf[7].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[0].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[1].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[2].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[3].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[4].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[5].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[6].u_drv}] ; # break_timing_path/ideal_network
set_dont_touch [get_cells {u_core/u_phase_buf_fast/gen_phase_buf[7].u_drv}] ; # break_timing_path/ideal_network
