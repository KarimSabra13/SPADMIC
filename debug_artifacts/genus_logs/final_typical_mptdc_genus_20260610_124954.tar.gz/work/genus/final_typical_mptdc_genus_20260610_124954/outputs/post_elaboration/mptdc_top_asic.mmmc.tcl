#################################################################################
#
# Created by Genus(TM) Synthesis Solution 22.13-s093_1 on Wed Jun 10 12:50:35 CEST 2026
#
#################################################################################

## library_sets
create_library_set -name tc_libset \
    -timing { /data/pdk/xfab/xh018/diglibs/D_CELLS_HD/v6_0/liberty_LPMOS/v6_0_0/PVT_1_80V_range/D_CELLS_HD_LPMOS_typ_1_80V_25C.lib \
              /home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/macros/mptdc_osc_blackbox.lib \
              /home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/macros/RO_tune4_real_abstract_shell.lib }

## timing_condition
create_timing_condition -name tc_cond \
    -library_sets { tc_libset }

## rc_corner
create_rc_corner -name tc_rc \
    -temperature 25.0 \
    -qrc_tech /data/pdk/xfab/xh018/cadence/v10_1/QRC_pvs/v10_1_1/XH018_1141/QRC-Typ/qrcTechFile \
    -pre_route_res 1.0 \
    -pre_route_cap 1.0 \
    -pre_route_clock_res 0.0 \
    -pre_route_clock_cap 0.0 \
    -post_route_res {1.0 1.0 1.0} \
    -post_route_cap {1.0 1.0 1.0} \
    -post_route_cross_cap {1.0 1.0 1.0} \
    -post_route_clock_res {1.0 1.0 1.0} \
    -post_route_clock_cap {1.0 1.0 1.0} \
    -post_route_clock_cross_cap {1.0 1.0 1.0}

## delay_corner
create_delay_corner -name tc_corner \
    -early_timing_condition { tc_cond } \
    -late_timing_condition { tc_cond } \
    -early_rc_corner tc_rc \
    -late_rc_corner tc_rc

## constraint_mode
create_constraint_mode -name functional_mode \
    -sdc_files { /home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954/outputs/post_elaboration/mptdc_top_asic.functional_mode.sdc }

## analysis_view
create_analysis_view -name tc_view \
    -constraint_mode functional_mode \
    -delay_corner tc_corner

## set_analysis_view
set_analysis_view -setup { tc_view } \
                  -hold { tc_view }
