################################################################################
#
# Genus(TM) Synthesis Solution setup file
# Created by Genus(TM) Synthesis Solution 22.13-s093_1
#   on 06/10/2026 12:50:39
#
# This file can only be run in Genus Common UI mode.
#
################################################################################


# This script is intended for use with Genus(TM) Synthesis Solution version 22.13-s093_1


# Remove Existing Design
################################################################################
if {[::legacy::find -design design:mptdc_top_asic] ne ""} {
  puts "** A design with the same name is already loaded. It will be removed. **"
  delete_obj design:mptdc_top_asic
}


# To allow user-readonly attributes
################################################################################
::legacy::set_attribute -quiet force_tui_is_remote 1 /


# Source INIT Setup file
################################################################################
source /home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954/outputs/post_elaboration/mptdc_top_asic.genus_init.tcl
read_metric -id current /home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954/outputs/post_elaboration/mptdc_top_asic.metrics.json

phys::read_script /home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954/outputs/post_elaboration/mptdc_top_asic.g

phys::read_lec_taf /home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954/outputs/post_elaboration/mptdc_top_asic.lec.taf.gz
puts "\n** Restoration Completed **\n"


# Data Integrity Check
################################################################################
# program version
if {"[string_representation [::legacy::get_attribute program_version /]]" != "22.13-s093_1"} {
   mesg_send [::legacy::find -message /messages/PHYS/PHYS-91] "golden program_version: 22.13-s093_1  current program_version: [string_representation [::legacy::get_attribute program_version /]]"
}
# license
if {"[string_representation [::legacy::get_attribute startup_license /]]" != "Genus_Synthesis"} {
   mesg_send [::legacy::find -message /messages/PHYS/PHYS-91] "golden license: Genus_Synthesis  current license: [string_representation [::legacy::get_attribute startup_license /]]"
}
# slack
set _slk_ [::legacy::get_attribute slack design:mptdc_top_asic]
if {[regexp {^-?[0-9.]+$} $_slk_]} {
  set _slk_ [format %.1f $_slk_]
}
if {$_slk_ != "-521.8"} {
   mesg_send [::legacy::find -message /messages/PHYS/PHYS-92] "golden slack: -521.8,  current slack: $_slk_"
}
unset _slk_
# multi-mode slack
if {"[string_representation [::legacy::get_attribute slack_by_mode design:mptdc_top_asic]]" != "{{mode:mptdc_top_asic/tc_view -521.8}}"} {
   mesg_send [::legacy::find -message /messages/PHYS/PHYS-92] "golden slack_by_mode: {{mode:mptdc_top_asic/tc_view -521.8}}  current slack_by_mode: [string_representation [::legacy::get_attribute slack_by_mode design:mptdc_top_asic]]"
}
# tns
set _tns_ [::legacy::get_attribute tns design:mptdc_top_asic]
if {[regexp {^-?[0-9.]+$} $_tns_]} {
  set _tns_ [format %.0f $_tns_]
}
if {$_tns_ != "108428"} {
   mesg_send [::legacy::find -message /messages/PHYS/PHYS-92] "golden tns: 108428,  current tns: $_tns_"
}
unset _tns_
# cell area
set _cell_area_ [::legacy::get_attribute cell_area design:mptdc_top_asic]
if {[regexp {^-?[0-9.]+$} $_cell_area_]} {
  set _cell_area_ [format %.0f $_cell_area_]
}
if {$_cell_area_ != "459378"} {
   mesg_send [::legacy::find -message /messages/PHYS/PHYS-92] "golden cell area: 459378,  current cell area: $_cell_area_"
}
unset _cell_area_
# net area
set _net_area_ [::legacy::get_attribute net_area design:mptdc_top_asic]
if {[regexp {^-?[0-9.]+$} $_net_area_]} {
  set _net_area_ [format %.0f $_net_area_]
}
if {$_net_area_ != "1087"} {
   mesg_send [::legacy::find -message /messages/PHYS/PHYS-92] "golden net area: 1087,  current net area: $_net_area_"
}
unset _net_area_
# library domain count
if {[llength [::legacy::find /libraries -library_domain *]] != "1"} {
   mesg_send [::legacy::find -message /messages/PHYS/PHYS-92] "golden # library domains: 1  current # library domains: [llength [::legacy::find /libraries -library_domain *]]"
}
