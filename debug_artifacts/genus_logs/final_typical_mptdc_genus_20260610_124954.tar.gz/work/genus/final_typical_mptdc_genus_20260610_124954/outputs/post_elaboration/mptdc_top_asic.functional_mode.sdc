# ####################################################################

#  Created by Genus(TM) Synthesis Solution 22.13-s093_1 on Wed Jun 10 12:50:35 CEST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design mptdc_top_asic

set_case_analysis 0 [get_ports narrow_ready_i]
set_case_analysis 1 [get_ports shared_readout_en_i]
create_clock -name "clk_sys" -period 6.25 -waveform {0.0 3.125} [get_ports clk_sys]
create_clock -name "clk_osc_slow" -period 1.43 -waveform {0.0 0.715} [get_pins {u_core/u_osc_slow/u_ro_tune4/S[0]}]
create_clock -name "clk_osc_slow_tap1" -period 1.43 -waveform {0.079 0.794} [get_pins {u_core/u_osc_slow/u_ro_tune4/S[1]}]
create_clock -name "clk_osc_slow_tap2" -period 1.43 -waveform {0.158 0.873} [get_pins {u_core/u_osc_slow/u_ro_tune4/S[2]}]
create_clock -name "clk_osc_slow_tap3" -period 1.43 -waveform {0.237 0.952} [get_pins {u_core/u_osc_slow/u_ro_tune4/S[3]}]
create_clock -name "clk_osc_slow_tap4" -period 1.43 -waveform {0.316 1.031} [get_pins {u_core/u_osc_slow/u_ro_tune4/S[4]}]
create_clock -name "clk_osc_slow_tap5" -period 1.43 -waveform {0.395 1.11} [get_pins {u_core/u_osc_slow/u_ro_tune4/S[5]}]
create_clock -name "clk_osc_slow_tap6" -period 1.43 -waveform {0.474 1.189} [get_pins {u_core/u_osc_slow/u_ro_tune4/S[6]}]
create_clock -name "clk_osc_slow_tap7" -period 1.43 -waveform {0.553 1.268} [get_pins {u_core/u_osc_slow/u_ro_tune4/S[7]}]
create_clock -name "clk_osc_fast" -period 1.333 -waveform {0.0 0.6665} [get_pins {u_core/u_osc_fast/u_ro_tune4/S[0]}]
create_clock -name "clk_osc_fast_tap1" -period 1.333 -waveform {0.074 0.7405} [get_pins {u_core/u_osc_fast/u_ro_tune4/S[1]}]
create_clock -name "clk_osc_fast_tap2" -period 1.333 -waveform {0.148 0.8145} [get_pins {u_core/u_osc_fast/u_ro_tune4/S[2]}]
create_clock -name "clk_osc_fast_tap3" -period 1.333 -waveform {0.222 0.8885} [get_pins {u_core/u_osc_fast/u_ro_tune4/S[3]}]
create_clock -name "clk_osc_fast_tap4" -period 1.333 -waveform {0.296 0.9625} [get_pins {u_core/u_osc_fast/u_ro_tune4/S[4]}]
create_clock -name "clk_osc_fast_tap5" -period 1.333 -waveform {0.37 1.0365} [get_pins {u_core/u_osc_fast/u_ro_tune4/S[5]}]
create_clock -name "clk_osc_fast_tap6" -period 1.333 -waveform {0.444 1.1105} [get_pins {u_core/u_osc_fast/u_ro_tune4/S[6]}]
create_clock -name "clk_osc_fast_tap7" -period 1.333 -waveform {0.518 1.1845} [get_pins {u_core/u_osc_fast/u_ro_tune4/S[7]}]
create_generated_clock -name "clk_osc_slow_buf_tap0" -divide_by 1     -source [get_pins {u_core/u_osc_slow/u_ro_tune4/S[0]}]   [get_pins {u_core/u_phase_buf_slow/gen_phase_buf[0].u_drv/Q}] 
create_generated_clock -name "clk_osc_slow_buf_tap1" -divide_by 1     -source [get_pins {u_core/u_osc_slow/u_ro_tune4/S[1]}]   [get_pins {u_core/u_phase_buf_slow/gen_phase_buf[1].u_drv/Q}] 
create_generated_clock -name "clk_osc_slow_buf_tap2" -divide_by 1     -source [get_pins {u_core/u_osc_slow/u_ro_tune4/S[2]}]   [get_pins {u_core/u_phase_buf_slow/gen_phase_buf[2].u_drv/Q}] 
create_generated_clock -name "clk_osc_slow_buf_tap3" -divide_by 1     -source [get_pins {u_core/u_osc_slow/u_ro_tune4/S[3]}]   [get_pins {u_core/u_phase_buf_slow/gen_phase_buf[3].u_drv/Q}] 
create_generated_clock -name "clk_osc_slow_buf_tap4" -divide_by 1     -source [get_pins {u_core/u_osc_slow/u_ro_tune4/S[4]}]   [get_pins {u_core/u_phase_buf_slow/gen_phase_buf[4].u_drv/Q}] 
create_generated_clock -name "clk_osc_slow_buf_tap5" -divide_by 1     -source [get_pins {u_core/u_osc_slow/u_ro_tune4/S[5]}]   [get_pins {u_core/u_phase_buf_slow/gen_phase_buf[5].u_drv/Q}] 
create_generated_clock -name "clk_osc_slow_buf_tap6" -divide_by 1     -source [get_pins {u_core/u_osc_slow/u_ro_tune4/S[6]}]   [get_pins {u_core/u_phase_buf_slow/gen_phase_buf[6].u_drv/Q}] 
create_generated_clock -name "clk_osc_slow_buf_tap7" -divide_by 1     -source [get_pins {u_core/u_osc_slow/u_ro_tune4/S[7]}]   [get_pins {u_core/u_phase_buf_slow/gen_phase_buf[7].u_drv/Q}] 
create_generated_clock -name "clk_osc_fast_buf_tap0" -divide_by 1     -source [get_pins {u_core/u_osc_fast/u_ro_tune4/S[0]}]   [get_pins {u_core/u_phase_buf_fast/gen_phase_buf[0].u_drv/Q}] 
create_generated_clock -name "clk_osc_fast_buf_tap1" -divide_by 1     -source [get_pins {u_core/u_osc_fast/u_ro_tune4/S[1]}]   [get_pins {u_core/u_phase_buf_fast/gen_phase_buf[1].u_drv/Q}] 
create_generated_clock -name "clk_osc_fast_buf_tap2" -divide_by 1     -source [get_pins {u_core/u_osc_fast/u_ro_tune4/S[2]}]   [get_pins {u_core/u_phase_buf_fast/gen_phase_buf[2].u_drv/Q}] 
create_generated_clock -name "clk_osc_fast_buf_tap3" -divide_by 1     -source [get_pins {u_core/u_osc_fast/u_ro_tune4/S[3]}]   [get_pins {u_core/u_phase_buf_fast/gen_phase_buf[3].u_drv/Q}] 
create_generated_clock -name "clk_osc_fast_buf_tap4" -divide_by 1     -source [get_pins {u_core/u_osc_fast/u_ro_tune4/S[4]}]   [get_pins {u_core/u_phase_buf_fast/gen_phase_buf[4].u_drv/Q}] 
create_generated_clock -name "clk_osc_fast_buf_tap5" -divide_by 1     -source [get_pins {u_core/u_osc_fast/u_ro_tune4/S[5]}]   [get_pins {u_core/u_phase_buf_fast/gen_phase_buf[5].u_drv/Q}] 
create_generated_clock -name "clk_osc_fast_buf_tap6" -divide_by 1     -source [get_pins {u_core/u_osc_fast/u_ro_tune4/S[6]}]   [get_pins {u_core/u_phase_buf_fast/gen_phase_buf[6].u_drv/Q}] 
create_generated_clock -name "clk_osc_fast_buf_tap7" -divide_by 1     -source [get_pins {u_core/u_osc_fast/u_ro_tune4/S[7]}]   [get_pins {u_core/u_phase_buf_fast/gen_phase_buf[7].u_drv/Q}] 
set_clock_transition 0.15 [get_clocks clk_sys]
set_clock_transition 0.15 [get_clocks clk_osc_slow]
set_clock_transition 0.15 [get_clocks clk_osc_slow_tap1]
set_clock_transition 0.15 [get_clocks clk_osc_slow_tap2]
set_clock_transition 0.15 [get_clocks clk_osc_slow_tap3]
set_clock_transition 0.15 [get_clocks clk_osc_slow_tap4]
set_clock_transition 0.15 [get_clocks clk_osc_slow_tap5]
set_clock_transition 0.15 [get_clocks clk_osc_slow_tap6]
set_clock_transition 0.15 [get_clocks clk_osc_slow_tap7]
set_clock_transition 0.15 [get_clocks clk_osc_fast]
set_clock_transition 0.15 [get_clocks clk_osc_fast_tap1]
set_clock_transition 0.15 [get_clocks clk_osc_fast_tap2]
set_clock_transition 0.15 [get_clocks clk_osc_fast_tap3]
set_clock_transition 0.15 [get_clocks clk_osc_fast_tap4]
set_clock_transition 0.15 [get_clocks clk_osc_fast_tap5]
set_clock_transition 0.15 [get_clocks clk_osc_fast_tap6]
set_clock_transition 0.15 [get_clocks clk_osc_fast_tap7]
set_load -pin_load 0.01 [get_ports csr_ready_o]
set_load -pin_load 0.01 [get_ports csr_rvalid_o]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[31]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[30]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[29]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[28]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[27]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[26]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[25]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[24]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[23]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[22]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[21]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[20]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[19]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[18]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[17]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[16]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[15]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[14]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[13]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[12]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[11]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[10]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[9]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[8]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[7]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[6]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[5]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[4]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[3]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[2]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[1]}]
set_load -pin_load 0.01 [get_ports {csr_rdata_o[0]}]
set_load -pin_load 0.01 [get_ports narrow_valid_o]
set_load -pin_load 0.01 [get_ports {narrow_data_o[15]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[14]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[13]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[12]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[11]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[10]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[9]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[8]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[7]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[6]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[5]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[4]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[3]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[2]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[1]}]
set_load -pin_load 0.01 [get_ports {narrow_data_o[0]}]
set_load -pin_load 0.01 [get_ports acq_valid_o]
set_load -pin_load 0.01 [get_ports {acq_data_o[52]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[51]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[50]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[49]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[48]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[47]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[46]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[45]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[44]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[43]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[42]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[41]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[40]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[39]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[38]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[37]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[36]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[35]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[34]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[33]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[32]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[31]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[30]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[29]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[28]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[27]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[26]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[25]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[24]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[23]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[22]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[21]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[20]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[19]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[18]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[17]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[16]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[15]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[14]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[13]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[12]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[11]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[10]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[9]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[8]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[7]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[6]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[5]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[4]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[3]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[2]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[1]}]
set_load -pin_load 0.01 [get_ports {acq_data_o[0]}]
set_load -pin_load 0.01 [get_ports fifo_full_o]
set_false_path -from [list \
  [get_ports start_spad_async_i]  \
  [get_ports stop_spad_async_i]  \
  [get_ports cal_start_async_i]  \
  [get_ports cal_stop_async_i]  \
  [get_ports async_rst_n] ]
set_false_path -to [list \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/start_wdt_cnt_reg[15]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[14]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[13]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[12]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[11]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[10]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[9]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[8]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[7]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[6]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[5]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[4]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[3]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[2]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[1]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[0]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[15]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[14]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[13]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[12]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[11]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[10]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[9]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[8]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[7]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[6]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[5]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[4]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[3]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[2]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[1]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[0]/aclr}]  \
  [get_pins u_core/start_timeout_latched_reg/srl]  \
  [get_pins u_core/start_timeout_latched_reg/aclr]  \
  [get_pins u_core/u_stop_capture/phase0_snap_o_reg/d]  \
  [get_pins u_core/u_stop_capture/phase7d_snap_o_reg/d]  \
  [get_pins u_core/u_stop_capture/slow_boundary_inc_o_reg/d]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[2]/d}]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[1]/d}]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[0]/d}] ]
set_false_path -through [list \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[7].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[6].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[5].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[4].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[3].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[2].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[1].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[7].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[6].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[5].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[4].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[3].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[2].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[1].u_pd/clear_window}]  \
  [get_pins {u_core/gen_pd_row[0].gen_pd_col[0].u_pd/clear_window}]  \
  [get_pins {u_core/start_wdt_cnt_reg[15]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[14]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[13]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[12]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[11]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[10]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[9]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[8]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[7]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[6]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[5]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[4]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[3]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[2]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[1]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[0]/srl}]  \
  [get_pins {u_core/start_wdt_cnt_reg[15]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[14]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[13]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[12]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[11]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[10]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[9]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[8]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[7]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[6]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[5]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[4]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[3]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[2]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[1]/aclr}]  \
  [get_pins {u_core/start_wdt_cnt_reg[0]/aclr}]  \
  [get_pins u_core/start_timeout_latched_reg/srl]  \
  [get_pins u_core/start_timeout_latched_reg/aclr]  \
  [get_pins u_core/u_stop_capture/phase0_snap_o_reg/d]  \
  [get_pins u_core/u_stop_capture/phase7d_snap_o_reg/d]  \
  [get_pins u_core/u_stop_capture/slow_boundary_inc_o_reg/d]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[2]/d}]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[1]/d}]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[0]/d}] ]
set_max_delay 6.25 -from [list \
  [get_clocks clk_osc_slow_tap7]  \
  [get_clocks clk_osc_slow_tap6]  \
  [get_clocks clk_osc_slow_tap5]  \
  [get_clocks clk_osc_slow_tap4]  \
  [get_clocks clk_osc_slow_tap3]  \
  [get_clocks clk_osc_slow_tap2]  \
  [get_clocks clk_osc_slow_tap1]  \
  [get_clocks clk_osc_slow]  \
  [get_clocks clk_osc_fast_tap7]  \
  [get_clocks clk_osc_fast_tap6]  \
  [get_clocks clk_osc_fast_tap5]  \
  [get_clocks clk_osc_fast_tap4]  \
  [get_clocks clk_osc_fast_tap3]  \
  [get_clocks clk_osc_fast_tap2]  \
  [get_clocks clk_osc_fast_tap1]  \
  [get_clocks clk_osc_fast] ] -to [get_clocks clk_sys]
set_max_delay 1.333 -from [get_clocks clk_sys] -to [list \
  [get_clocks clk_osc_fast]  \
  [get_clocks clk_osc_fast_tap1]  \
  [get_clocks clk_osc_fast_tap2]  \
  [get_clocks clk_osc_fast_tap3]  \
  [get_clocks clk_osc_fast_tap4]  \
  [get_clocks clk_osc_fast_tap5]  \
  [get_clocks clk_osc_fast_tap6]  \
  [get_clocks clk_osc_fast_tap7] ]
set_max_delay 6.25 -from [list \
  [get_pins u_core/u_stop_capture/phase0_snap_o_reg/q]  \
  [get_pins u_core/u_stop_capture/slow_boundary_inc_o_reg/q]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[2]/q}]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[1]/q}]  \
  [get_pins {u_core/u_stop_capture/stop_slow_phase_disc_o_reg[0]/q}] ] -to [list \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][63]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][62]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][61]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][60]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][59]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][58]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][57]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][56]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][55]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][54]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][53]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][52]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][51]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][50]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][49]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][48]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][47]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][46]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][45]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][44]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][43]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][42]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][41]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][40]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][39]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][38]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][37]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][36]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][35]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][34]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][33]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][32]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][31]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][30]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][29]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][28]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][27]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][26]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][25]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][24]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][23]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][22]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][21]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][20]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][19]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][18]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][17]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][16]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][15]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][14]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][13]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][12]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][11]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][10]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][9]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][8]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][7]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][6]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][5]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][4]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][3]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][2]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][1]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[hit_level][0]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][447]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][446]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][445]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][444]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][443]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][442]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][441]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][440]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][439]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][438]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][437]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][436]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][435]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][434]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][433]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][432]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][431]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][430]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][429]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][428]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][427]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][426]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][425]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][424]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][423]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][422]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][421]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][420]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][419]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][418]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][417]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][416]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][415]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][414]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][413]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][412]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][411]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][410]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][409]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][408]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][407]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][406]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][405]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][404]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][403]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][402]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][401]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][400]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][399]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][398]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][397]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][396]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][395]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][394]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][393]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][392]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][391]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][390]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][389]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][388]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][387]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][386]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][385]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][384]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][383]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][382]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][381]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][380]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][379]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][378]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][377]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][376]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][375]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][374]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][373]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][372]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][371]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][370]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][369]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][368]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][367]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][366]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][365]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][364]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][363]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][362]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][361]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][360]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][359]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][358]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][357]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][356]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][355]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][354]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][353]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][352]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][351]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][350]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][349]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][348]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][347]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][346]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][345]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][344]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][343]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][342]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][341]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][340]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][339]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][338]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][337]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][336]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][335]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][334]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][333]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][332]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][331]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][330]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][329]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][328]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][327]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][326]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][325]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][324]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][323]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][322]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][321]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][320]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][319]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][318]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][317]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][316]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][315]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][314]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][313]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][312]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][311]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][310]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][309]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][308]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][307]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][306]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][305]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][304]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][303]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][302]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][301]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][300]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][299]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][298]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][297]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][296]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][295]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][294]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][293]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][292]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][291]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][290]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][289]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][288]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][287]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][286]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][285]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][284]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][283]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][282]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][281]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][280]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][279]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][278]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][277]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][276]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][275]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][274]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][273]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][272]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][271]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][270]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][269]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][268]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][267]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][266]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][265]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][264]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][263]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][262]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][261]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][260]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][259]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][258]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][257]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][256]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][255]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][254]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][253]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][252]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][251]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][250]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][249]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][248]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][247]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][246]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][245]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][244]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][243]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][242]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][241]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][240]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][239]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][238]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][237]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][236]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][235]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][234]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][233]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][232]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][231]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][230]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][229]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][228]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][227]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][226]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][225]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][224]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][223]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][222]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][221]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][220]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][219]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][218]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][217]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][216]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][215]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][214]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][213]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][212]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][211]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][210]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][209]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][208]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][207]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][206]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][205]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][204]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][203]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][202]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][201]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][200]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][199]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][198]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][197]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][196]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][195]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][194]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][193]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][192]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][191]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][190]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][189]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][188]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][187]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][186]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][185]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][184]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][183]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][182]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][181]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][180]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][179]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][178]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][177]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][176]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][175]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][174]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][173]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][172]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][171]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][170]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][169]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][168]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][167]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][166]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][165]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][164]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][163]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][162]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][161]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][160]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][159]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][158]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][157]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][156]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][155]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][154]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][153]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][152]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][151]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][150]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][149]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][148]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][147]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][146]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][145]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][144]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][143]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][142]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][141]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][140]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][139]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][138]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][137]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][136]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][135]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][134]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][133]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][132]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][131]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][130]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][129]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][128]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][127]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][126]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][125]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][124]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][123]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][122]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][121]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][120]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][119]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][118]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][117]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][116]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][115]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][114]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][113]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][112]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][111]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][110]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][109]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][108]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][107]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][106]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][105]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][104]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][103]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][102]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][101]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][100]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][99]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][98]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][97]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][96]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][95]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][94]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][93]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][92]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][91]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][90]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][89]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][88]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][87]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][86]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][85]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][84]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][83]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][82]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][81]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][80]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][79]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][78]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][77]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][76]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][75]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][74]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][73]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][72]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][71]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][70]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][69]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][68]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][67]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][66]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][65]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][64]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][63]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][62]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][61]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][60]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][59]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][58]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][57]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][56]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][55]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][54]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][53]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][52]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][51]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][50]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][49]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][48]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][47]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][46]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][45]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][44]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][43]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][42]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][41]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][40]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][39]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][38]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][37]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][36]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][35]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][34]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][33]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][32]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][31]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][30]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][29]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][28]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][27]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][26]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][25]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][24]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][23]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][22]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][21]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][20]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][19]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][18]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][17]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][16]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][15]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][14]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][13]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][12]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][11]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][10]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][9]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][8]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][7]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][6]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][5]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][4]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][3]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][2]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][1]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_hit_packed][0]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nslow_snap][6]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nslow_snap][5]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nslow_snap][4]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nslow_snap][3]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nslow_snap][2]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nslow_snap][1]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nslow_snap][0]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_snap][6]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_snap][5]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_snap][4]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_snap][3]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_snap][2]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_snap][1]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[nfast_snap][0]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[phase0_snap]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[stop_slow_phase_disc][2]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[stop_slow_phase_disc][1]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[stop_slow_phase_disc][0]/d}]  \
  [get_pins {u_core/u_hit_capture_bridge/snapshot_q_reg[slow_boundary_inc]/d}] ]
set_clock_groups -name "clock_groups_clk_sys_to_clk_osc_slow_clk_osc_slow_tap1_clk_osc_slow_tap2_clk_osc_slow_tap3_clk_osc_slow_tap4_clk_osc_slow_tap5_clk_osc_slow_tap6_clk_osc_slow_tap7_to_clk_osc_fast_clk_osc_fast_tap1_clk_osc_fast_tap2_clk_osc_fast_tap3_clk_osc_fast_tap4_clk_osc_fast_tap5_clk_osc_fast_tap6_clk_osc_fast_tap7" -asynchronous -group [get_clocks clk_sys] -group [list \
  [get_clocks clk_osc_slow]  \
  [get_clocks clk_osc_slow_tap1]  \
  [get_clocks clk_osc_slow_tap2]  \
  [get_clocks clk_osc_slow_tap3]  \
  [get_clocks clk_osc_slow_tap4]  \
  [get_clocks clk_osc_slow_tap5]  \
  [get_clocks clk_osc_slow_tap6]  \
  [get_clocks clk_osc_slow_tap7] ] -group [list \
  [get_clocks clk_osc_fast]  \
  [get_clocks clk_osc_fast_tap1]  \
  [get_clocks clk_osc_fast_tap2]  \
  [get_clocks clk_osc_fast_tap3]  \
  [get_clocks clk_osc_fast_tap4]  \
  [get_clocks clk_osc_fast_tap5]  \
  [get_clocks clk_osc_fast_tap6]  \
  [get_clocks clk_osc_fast_tap7] ]
set_clock_groups -name "clock_groups_clk_sys_to_clk_osc_slow_clk_osc_slow_tap1_clk_osc_slow_tap2_clk_osc_slow_tap3_clk_osc_slow_tap4_clk_osc_slow_tap5_clk_osc_slow_tap6_clk_osc_slow_tap7_clk_osc_fast_clk_osc_fast_tap1_clk_osc_fast_tap2_clk_osc_fast_tap3_clk_osc_fast_tap4_clk_osc_fast_tap5_clk_osc_fast_tap6_clk_osc_fast_tap7_clk_osc_slow_buf_tap0_clk_osc_slow_buf_tap1_clk_osc_slow_buf_tap2_clk_osc_slow_buf_tap3_clk_osc_slow_buf_tap4_clk_osc_slow_buf_tap5_clk_osc_slow_buf_tap6_clk_osc_slow_buf_tap7_clk_osc_fast_buf_tap0_clk_osc_fast_buf_tap1_clk_osc_fast_buf_tap2_clk_osc_fast_buf_tap3_clk_osc_fast_buf_tap4_clk_osc_fast_buf_tap5_clk_osc_fast_buf_tap6_clk_osc_fast_buf_tap7" -asynchronous -group [get_clocks clk_sys] -group [list \
  [get_clocks clk_osc_slow]  \
  [get_clocks clk_osc_slow_tap1]  \
  [get_clocks clk_osc_slow_tap2]  \
  [get_clocks clk_osc_slow_tap3]  \
  [get_clocks clk_osc_slow_tap4]  \
  [get_clocks clk_osc_slow_tap5]  \
  [get_clocks clk_osc_slow_tap6]  \
  [get_clocks clk_osc_slow_tap7]  \
  [get_clocks clk_osc_fast]  \
  [get_clocks clk_osc_fast_tap1]  \
  [get_clocks clk_osc_fast_tap2]  \
  [get_clocks clk_osc_fast_tap3]  \
  [get_clocks clk_osc_fast_tap4]  \
  [get_clocks clk_osc_fast_tap5]  \
  [get_clocks clk_osc_fast_tap6]  \
  [get_clocks clk_osc_fast_tap7]  \
  [get_clocks clk_osc_slow_buf_tap0]  \
  [get_clocks clk_osc_slow_buf_tap1]  \
  [get_clocks clk_osc_slow_buf_tap2]  \
  [get_clocks clk_osc_slow_buf_tap3]  \
  [get_clocks clk_osc_slow_buf_tap4]  \
  [get_clocks clk_osc_slow_buf_tap5]  \
  [get_clocks clk_osc_slow_buf_tap6]  \
  [get_clocks clk_osc_slow_buf_tap7]  \
  [get_clocks clk_osc_fast_buf_tap0]  \
  [get_clocks clk_osc_fast_buf_tap1]  \
  [get_clocks clk_osc_fast_buf_tap2]  \
  [get_clocks clk_osc_fast_buf_tap3]  \
  [get_clocks clk_osc_fast_buf_tap4]  \
  [get_clocks clk_osc_fast_buf_tap5]  \
  [get_clocks clk_osc_fast_buf_tap6]  \
  [get_clocks clk_osc_fast_buf_tap7] ]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports input_sel_override_en_i]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {input_sel_override_i[0]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports out_mode_override_en_i]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {out_mode_override_i[1]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {out_mode_override_i[0]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports csr_valid_i]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports csr_write_i]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_addr_i[5]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_addr_i[4]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_addr_i[3]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_addr_i[2]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_addr_i[1]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_addr_i[0]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[31]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[30]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[29]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[28]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[27]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[26]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[25]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[24]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[23]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[22]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[21]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[20]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[19]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[18]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[17]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[16]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[15]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[14]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[13]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[12]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[11]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[10]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[9]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[8]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[7]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[6]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[5]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[4]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[3]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[2]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[1]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_wdata_i[0]}]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports narrow_ready_i]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports shared_readout_en_i]
set_input_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports acq_ready_i]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports csr_ready_o]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports csr_rvalid_o]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[31]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[30]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[29]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[28]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[27]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[26]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[25]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[24]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[23]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[22]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[21]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[20]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[19]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[18]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[17]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[16]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[15]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[14]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[13]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[12]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[11]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[10]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[9]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[8]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[7]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[6]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[5]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[4]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[3]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[2]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[1]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {csr_rdata_o[0]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports narrow_valid_o]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[15]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[14]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[13]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[12]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[11]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[10]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[9]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[8]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[7]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[6]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[5]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[4]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[3]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[2]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[1]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {narrow_data_o[0]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports acq_valid_o]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[52]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[51]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[50]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[49]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[48]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[47]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[46]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[45]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[44]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[43]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[42]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[41]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[40]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[39]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[38]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[37]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[36]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[35]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[34]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[33]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[32]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[31]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[30]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[29]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[28]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[27]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[26]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[25]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[24]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[23]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[22]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[21]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[20]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[19]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[18]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[17]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[16]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[15]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[14]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[13]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[12]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[11]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[10]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[9]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[8]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[7]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[6]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[5]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[4]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[3]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[2]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[1]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports {acq_data_o[0]}]
set_output_delay -clock [get_clocks clk_sys] -add_delay 0.5 [get_ports fifo_full_o]
set_max_fanout 20.000 [current_design]
set_max_transition 0.5 [current_design]
set_input_transition 0.1 [get_ports async_rst_n]
set_input_transition 0.1 [get_ports start_spad_async_i]
set_input_transition 0.1 [get_ports stop_spad_async_i]
set_input_transition 0.1 [get_ports cal_start_async_i]
set_input_transition 0.1 [get_ports cal_stop_async_i]
set_input_transition 0.1 [get_ports input_sel_override_en_i]
set_input_transition 0.1 [get_ports {input_sel_override_i[0]}]
set_input_transition 0.1 [get_ports out_mode_override_en_i]
set_input_transition 0.1 [get_ports {out_mode_override_i[1]}]
set_input_transition 0.1 [get_ports {out_mode_override_i[0]}]
set_input_transition 0.1 [get_ports csr_valid_i]
set_input_transition 0.1 [get_ports csr_write_i]
set_input_transition 0.1 [get_ports {csr_addr_i[5]}]
set_input_transition 0.1 [get_ports {csr_addr_i[4]}]
set_input_transition 0.1 [get_ports {csr_addr_i[3]}]
set_input_transition 0.1 [get_ports {csr_addr_i[2]}]
set_input_transition 0.1 [get_ports {csr_addr_i[1]}]
set_input_transition 0.1 [get_ports {csr_addr_i[0]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[31]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[30]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[29]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[28]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[27]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[26]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[25]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[24]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[23]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[22]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[21]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[20]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[19]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[18]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[17]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[16]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[15]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[14]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[13]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[12]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[11]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[10]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[9]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[8]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[7]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[6]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[5]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[4]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[3]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[2]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[1]}]
set_input_transition 0.1 [get_ports {csr_wdata_i[0]}]
set_input_transition 0.1 [get_ports narrow_ready_i]
set_input_transition 0.1 [get_ports shared_readout_en_i]
set_input_transition 0.1 [get_ports acq_ready_i]
set_ideal_network [get_ports clk_sys]
set_ideal_network [get_ports async_rst_n]
set_dont_touch [get_designs mptdc_phase_buffer_bank]
set_dont_touch [get_cells u_core/u_phase_buf_slow]
set_dont_touch [get_cells u_core/u_phase_buf_fast]
set_clock_uncertainty -setup 0.3 [get_clocks clk_sys]
set_clock_uncertainty -hold 0.3 [get_clocks clk_sys]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_tap1]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_tap1]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_tap2]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_tap2]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_tap3]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_tap3]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_tap4]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_tap4]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_tap5]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_tap5]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_tap6]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_tap6]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_tap7]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_tap7]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_tap1]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_tap1]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_tap2]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_tap2]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_tap3]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_tap3]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_tap4]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_tap4]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_tap5]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_tap5]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_tap6]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_tap6]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_tap7]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_tap7]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_buf_tap0]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_buf_tap0]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_buf_tap1]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_buf_tap1]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_buf_tap2]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_buf_tap2]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_buf_tap3]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_buf_tap3]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_buf_tap4]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_buf_tap4]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_buf_tap5]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_buf_tap5]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_buf_tap6]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_buf_tap6]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_slow_buf_tap7]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_slow_buf_tap7]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_buf_tap0]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_buf_tap0]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_buf_tap1]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_buf_tap1]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_buf_tap2]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_buf_tap2]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_buf_tap3]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_buf_tap3]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_buf_tap4]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_buf_tap4]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_buf_tap5]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_buf_tap5]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_buf_tap6]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_buf_tap6]
set_clock_uncertainty -setup 0.01 [get_clocks clk_osc_fast_buf_tap7]
set_clock_uncertainty -hold 0.005 [get_clocks clk_osc_fast_buf_tap7]
