################################################################################
#
# Init setup file
# Created by Genus(TM) Synthesis Solution on 06/10/2026 12:58:50
#
################################################################################
if { ![is_common_ui_mode] } { error "ERROR: This script requires common_ui to be active."}

read_mmmc /home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954/outputs/post_synth/mptdc_top_asic.mmmc.tcl

read_physical -lef {/data/pdk/xfab/xh018/cadence/v9_0/techLEF/v9_0_1/xh018_xx41_HD_MET4_METMID.lef /home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/macros/mptdc_osc_blackbox.lef /home/validmgr/ksabra/2026_SPAD/SPADMIC/work/macros/ro_tune4/RO_tune4_real_abstract.lef /data/pdk/xfab/xh018/diglibs/D_CELLS_HD/v6_0/LEF/v6_0_0/xh018_D_CELLS_HD.lef}

read_netlist /home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954/outputs/post_synth/mptdc_top_asic.v

init_design
