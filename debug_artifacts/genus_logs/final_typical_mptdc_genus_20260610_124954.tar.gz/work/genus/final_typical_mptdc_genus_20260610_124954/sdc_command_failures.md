# O13 abs3 SDC Command Failure Review

- Run ID: `final_typical_mptdc_genus_20260610_124954`
- SDC overlay: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/inputs/mptdc_pd_vernier_exceptions.sdc`
- Genus log: `genus_final_typical_mptdc_genus_20260610_124954.log`

## Extracted SDC/Timing-Intent Diagnostics

216:@file(procedures.tcl) 1766: proc mptdc_report_timing ...
1963:MPTDC_SDC_INFO: set_case_analysis 1 shared_readout_en_i
1964:MPTDC_SDC_INFO: set_case_analysis 0 narrow_ready_i
1973:-- The command 'set_false_path -to [get_pins -quiet -hierarchical $pattern]' is present in line '15' of proc '::mptdc_try_false_path_pins'
1974:-- The command passed to the interpreter is : '::dc::set_false_path -to 0x80'
1978:        : If, as a result of 'set_max_delay' or 'set_disable_timing' constraint operations, the to-point does not become a valid timing endpoint, then the exception will not be applied to this to-point.
1989:-- The command 'set_false_path -to [get_pins -quiet -hierarchical $pattern]' is present in line '15' of proc '::mptdc_try_false_path_pins'
1990:-- The command passed to the interpreter is : '::dc::set_false_path -to 0x84'
1996:MPTDC_SDC_INFO: false-pathing PD conversion clear pins (2 pattern-expanded pins)
1997:MPTDC_SDC_INFO: false-pathing PD conversion clear pins applied without pattern failures
1998:MPTDC_SDC_WARN: no pins matched for Gray counter async clear pins
1999:MPTDC_SDC_INFO: false-pathing START watchdog async clear pins (4 pattern-expanded pins)
2000:MPTDC_SDC_INFO: false-pathing START watchdog async clear pins applied without pattern failures
2001:MPTDC_SDC_INFO: false-pathing STOP metadata async capture data pins (5 pattern-expanded pins)
2002:MPTDC_SDC_INFO: false-pathing STOP metadata async capture data pins applied without pattern failures
2009:Warning : Invalid object passed to SDC command. [SDC-248] [set_dont_touch]
2014:MPTDC_SDC_INFO: max-delaying STOP metadata static bus into clk_sys snapshot from 4 pattern-expanded pin(s) to 2 pattern-expanded pin(s)
2015:MPTDC_SDC_INFO: max-delay STOP metadata static bus into clk_sys snapshot applied across 8 pattern pair(s)
2016:MPTDC_SDC_INFO: reset net max-transition target 0.35 ns for *rst_*_n* is checked by DRV reports; direct set_max_transition on nets is skipped because this Genus SDC mode rejects net objects
2017:MPTDC_SDC_INFO: reset net max-transition target 0.35 ns for *rst_n_o* is checked by DRV reports; direct set_max_transition on nets is skipped because this Genus SDC mode rejects net objects
2018:MPTDC_SDC_INFO: reset net max-transition target 0.35 ns for *rst_sys_*_n* is checked by DRV reports; direct set_max_transition on nets is skipped because this Genus SDC mode rejects net objects
2031: "set_clock_groups"         - successful      1 , failed      0 (runtime  0.00)
2035: "set_false_path"           - successful     27 , failed      0 (runtime  0.01)
2040: "set_max_delay"            - successful     11 , failed      0 (runtime  0.02)
2042: "set_max_transition"       - successful      1 , failed      0 (runtime  0.01)
2049:MPTDC_O13_ABS5_SDC_INFO: loading O13_ABS5_PD_Q1_EXCEPTION_EXACT_MATCH overlay
2050:MPTDC_O13_ABS5_SDC_INFO: sourcing O13 abs3 clock/CDC repair overlay first
2051:MPTDC_O13_ABS3_SDC_INFO: loading O13_ABS3_CLOCK_CDC_CONSTRAINT_REPAIR overlay
2052:MPTDC_O13_ABS3_SDC_INFO: signoff status = TYPICAL_ONLY_NOT_MMMC_NOT_FINAL_SIGNOFF
2053:MPTDC_O13_ABS3_SDC_INFO: expected RTL define = MPTDC_PHASE_BUFFER_TOPO_BUHDX4_BUHDX12
2054:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_slow_buf_tap0 from 0x191 to 0x223
2055:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_slow_buf_tap1 from 0x233 to 0x265
2056:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_slow_buf_tap2 from 0x275 to 0x307
2057:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_slow_buf_tap3 from 0x317 to 0x349
2058:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_slow_buf_tap4 from 0x359 to 0x391
2059:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_slow_buf_tap5 from 0x401 to 0x433
2060:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_slow_buf_tap6 from 0x443 to 0x475
2061:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_slow_buf_tap7 from 0x485 to 0x517
2062:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_fast_buf_tap0 from 0x527 to 0x559
2063:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_fast_buf_tap1 from 0x569 to 0x601
2064:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_fast_buf_tap2 from 0x611 to 0x643
2065:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_fast_buf_tap3 from 0x653 to 0x685
2066:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_fast_buf_tap4 from 0x695 to 0x727
2067:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_fast_buf_tap5 from 0x737 to 0x769
2068:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_fast_buf_tap6 from 0x779 to 0x811
2069:MPTDC_O13_ABS3_SDC_INFO: created clk_osc_fast_buf_tap7 from 0x821 to 0x853
2070:MPTDC_O13_ABS3_SDC_INFO: matched raw RO pins = 16
2071:MPTDC_O13_ABS3_SDC_INFO: matched BUHDX4 iso A pins = 16
2072:MPTDC_O13_ABS3_SDC_INFO: matched BUHDX4 iso Q pins = 16
2073:MPTDC_O13_ABS3_SDC_INFO: matched BUHDX12 driver A pins = 16
2074:MPTDC_O13_ABS3_SDC_INFO: matched BUHDX12 driver Q pins = 16
2075:MPTDC_O13_ABS3_SDC_INFO: raw clock count = 16
2076:MPTDC_O13_ABS3_SDC_INFO: buffer slow clock count = 8
2077:MPTDC_O13_ABS3_SDC_INFO: buffer fast clock count = 8
2078:MPTDC_O13_ABS3_SDC_INFO: generated final-driver clocks = 16
2079:MPTDC_O13_ABS3_SDC_INFO: oscillator clocks in async group = 32
2080:MPTDC_O13_ABS3_SDC_INFO: clk_sys async to raw+buffer oscillator clocks = YES
2081:MPTDC_O13_ABS3_SDC_INFO: raw RO clocks remain analog load-check source clocks
2082:MPTDC_O13_ABS3_SDC_INFO: BUHDX12 Q clocks are downstream digital phase-clock sources
2083:MPTDC_O13_ABS3_SDC_INFO: phase-buffer chain and same-domain oscillator paths remain timed
2085:MPTDC_O13_ABS5_SDC_INFO: PD_VERNIER_FOUND_ENDPOINTS=0
2086:MPTDC_O13_ABS5_SDC_INFO: PD_VERNIER_EXPECTED_ENDPOINTS=64
2087:MPTDC_O13_ABS5_SDC_INFO: PD_VERNIER_FOUND_SOURCES=8
2088:MPTDC_O13_ABS5_SDC_INFO: PD_VERNIER_EXPECTED_SOURCES=8
2089:MPTDC_O13_ABS5_SDC_INFO: PD_VERNIER_EXCEPTION_APPLIED=NO
2090:MPTDC_O13_ABS5_SDC_INFO: PD_VERNIER_OVERMATCH=NO
2091:MPTDC_O13_ABS5_SDC_INFO: PD_VERNIER_UNDERMATCH=YES
2092:MPTDC_O13_ABS5_SDC_INFO: PD_VERNIER_EXCEPTION_FAILURES=0
2099: "set_clock_groups"         - successful      1 , failed      0 (runtime  0.00)
2546:    {mptdc_report_timing $design(synthesis_reports)} \
6685:|SDC-248    |Warning|    1|Invalid object passed to SDC command.                                                                                                                                             |
6692:|           |       |     |If, as a result of 'set_max_delay' or 'set_disable_timing' constraint operations, the to-point does not become a valid timing endpoint, then the exception will not be applied to |
9053:    {mptdc_report_timing $design(synthesis_reports)} \
11528:    {mptdc_report_timing $design(synthesis_reports)} \
13111:    {mptdc_report_timing $design(synthesis_reports)} \

## Interpretation

- Object-handle SDC failures are expected to disappear after the abs3 helper repair.
- Final buffer clocks must be grouped asynchronously against clk_sys.
- Any remaining failed false-path, max-delay, clock-group, or generated-clock command requires review before Innovus.
