# MPTDC Genus Typical Summary

- Flow: `MPTDC_GENUS_TYPICAL`
- Mode: `MPTDC_TYPICAL_TIMING_CLOSURE`
- Package label: `TYPICAL_ONLY_TAPEOUT_PACKAGE`
- Signoff boundary: `TYPICAL_ONLY_NOT_MMMC`
- Legacy trace: `O13_ABS5_PD_Q1_EXCEPTION_EXACT_MATCH`
- Run ID: `final_typical_mptdc_genus_20260610_124954`
- Run mode: `O13_ABS5_PD_Q1_EXCEPTION_EXACT_MATCH`
- Branch: `SPADMIC_FINAL`
- Git HEAD: `1a1e590bbb44db96fd7b44e24e5530adb80ae43a`
- Genus exit code: 1
- Snapshot exit code: 0
- Result directory: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/work/genus/final_typical_mptdc_genus_20260610_124954`
- TYPICAL_ONLY_TAPEOUT_PACKAGE: YES
- NOT_MMMC_SIGNOFF: YES
- FINAL_SIGNOFF: NO
- Signoff status: `TYPICAL_ONLY_TAPEOUT_PACKAGE_NOT_MMMC_SIGNOFF_NOT_FINAL_SIGNOFF`
- Frequency mode: `r750_delta5`
- Phase distribution: `BUHDX4 -> BUHDX12`
- Packet format: unchanged
- raw_lfsr_tag: unchanged
- NFAST encoding: `raw_lfsr_tag`
- Phase buffer topology: `BUHDX4 -> BUHDX12 per tap`
- HDL filelist: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/filelist_o13_phase_distribution.f`
- SDC overlay: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/inputs/mptdc_pd_vernier_exceptions.sdc`
- RO_tune4 instance count: 2
- mptdc_osc_stub residue count: 0
- BUHDX4 instance count: 23
- BUHDX12 instance count: 18
- phase-buffer hierarchy text count: 3
- u_iso text count: 8
- u_drv text count: 8
- report_clocks RO_tune4/S match count: 16
- report_clocks final-driver generated-clock count: 0
- RAW_RO_CLOCKS_FOUND: 16
- BUFFER_PHASE_CLOCKS_FOUND: 16
- BUFFER_PHASE_CLOCKS_EXPECTED: 16
- BUFFER_PHASE_CLOCKS_IN_ASYNC_GROUP: YES
- CLK_SYS_ASYNC_TO_BUFFER_PHASE_CLOCKS: YES
- PD intentional Vernier paths expected: 64
- PD intentional Vernier paths matched: 64
- PD intentional Vernier sources matched: 8
- PD intentional Vernier exception applied: YES
- PD intentional Vernier overmatch: NO
- PD intentional Vernier undermatch: NO
- UNKNOWN_REVIEW_REQUIRED count: 0
- SDC command failure count: 0
- Max transition violations: 1015
- Max capacitance violations: 0
- Max fanout violations: 0
- Real timed WNS ps: 1.0
- Real timed TNS ps: 0.0
- Worst real path family: FAST_TAG_TO_PD_TS

FINAL_DECISION=GENUS_TYPICAL_REVIEW_REQUIRED
GENUS_TYPICAL_STATUS=GENUS_TYPICAL_REVIEW_REQUIRED
LEGACY_TRACE=O13_ABS5_PD_Q1_EXCEPTION_EXACT_MATCH
FINAL_SIGNOFF=NO
TYPICAL_ONLY_TAPEOUT_PACKAGE=YES
NOT_MMMC_SIGNOFF=YES
INNOVUS_READY=NO_REVIEW_O13_ABS5_GENUS_FIRST

## Key Files
- present: `genus_final_typical_mptdc_genus_20260610_124954.log`
- present: `mptdc_top_asic.postsyn.v`
- present: `mptdc_top_asic.postsyn.sdc`
- present: `final_sdc_overlay_used.sdc`
- present: `final_filelist_used.f`
- present: `o13_phase_distribution_check.rpt`
- present: `run_manifest.txt`
- present: `report_clocks.rpt`
- present: `report_clocks_generated.rpt`
- present: `report_clock_groups.rpt`
- present: `report_exceptions.rpt`
- present: `check_timing_intent_post_synth.rpt`
- present: `report_design_rules.rpt`
- present: `report_high_fanout.rpt`
- present: `report_area.rpt`
- present: `report_qor.rpt`
- present: `timing_summary.rpt`
- present: `timing_violations.rpt`
- present: `timing_pd_capture_hotspots.rpt`
- present: `timing_clk_sys_violations.rpt`
- present: `timing_clk_sys_internal_top100.rpt`
- present: `timing_cdc_async_review.rpt`
- present: `timing_pd_intentional_vernier.rpt`
- present: `pd_vernier_exception_check.rpt`
- present: `pd_vernier_endpoint_discovery.rpt`
- present: `pd_vernier_source_discovery.rpt`
- present: `timing_o13_phase_buffer_paths.rpt`
- present: `o13_clock_model_check.rpt`
- present: `o13_clock_model_check.sdc.rpt`
- present: `sdc_command_failures.md`
- present: `macro_binding_check.rpt`
- present: `packet_contract_check.rpt`
- present: `final_typical_genus_readiness.md`
- present: `timing_path_classification.csv`
- present: `timing_path_classification_summary.md`
