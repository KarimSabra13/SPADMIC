# Cadence Genus(TM) Synthesis Solution, Version 22.13-s093_1, built Sep  5 2023 17:56:02

# Date: Wed Jun 10 12:49:55 2026
# Host: lyoelectrosrv01.in2p3.fr (x86_64 w/Linux 4.18.0-553.120.1.el8_10.x86_64) (16cores*64cpus*2physical cpus*Intel(R) Xeon(R) Silver 4216 CPU @ 2.10GHz 22528KB)
# OS:   Rocky Linux release 8.10 (Green Obsidian)

source /home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/scripts/genus.tcl
exit
