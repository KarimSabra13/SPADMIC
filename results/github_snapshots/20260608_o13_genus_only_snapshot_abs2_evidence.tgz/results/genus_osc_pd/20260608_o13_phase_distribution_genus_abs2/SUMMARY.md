# Genus O13 Phase Distribution Summary

- Run ID: `20260608_o13_phase_distribution_genus_abs2`
- Run mode: `typical_synth`
- Git HEAD: `17854931400b21ca755b013c5b5e79e839330ccc`
- Genus exit code: 0
- Snapshot exit code: 0
- Signoff status: `TYPICAL_ONLY_NOT_MMMC_NOT_FINAL_SIGNOFF`
- Frequency mode: `r750_delta5`
- Packet format: unchanged
- NFAST encoding: `raw_lfsr_tag`
- Phase buffer topology: `BUHDX4 -> BUHDX12 per tap`
- HDL filelist: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/filelist_o13_phase_distribution.f`
- SDC overlay: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/inputs/mptdc_osc_typical_r750_delta5_o13_phase_distribution.sdc`
- RO_tune4 instance count: 2
- mptdc_osc_stub residue count: 0
- BUHDX4 instance count: 54
- BUHDX12 instance count: 17
- phase-buffer hierarchy text count: 3
- u_iso text count: 8
- u_drv text count: 8
- report_clocks RO_tune4/S match count: 16
- report_clocks final-driver generated-clock count: 0

O13_STATUS=O13_NETLIST_CANDIDATE
FINAL_SIGNOFF=NO
INNOVUS_READY=RUN_O13_PHASE_DISTRIBUTION_FEASIBILITY_AFTER_REVIEW

## Key Files
- present: `genus_20260608_o13_phase_distribution_genus_abs2.log`
- present: `mptdc_top_asic.postsyn.v`
- present: `mptdc_top_asic.postsyn.sdc`
- present: `final_sdc_overlay_used.sdc`
- present: `final_filelist_used.f`
- present: `o13_phase_distribution_check.rpt`
- present: `run_manifest.txt`
- present: `report_clocks.rpt`
- present: `report_design_rules.rpt`
- present: `report_high_fanout.rpt`
- present: `timing_summary.rpt`
- present: `timing_violations.rpt`
- present: `timing_pd_capture_hotspots.rpt`
- present: `timing_clk_sys_violations.rpt`
