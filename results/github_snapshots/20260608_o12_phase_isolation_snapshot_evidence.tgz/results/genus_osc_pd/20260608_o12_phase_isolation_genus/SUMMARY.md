# Genus O12 Phase Isolation Buffer Summary

- Run ID: `20260608_o12_phase_isolation_genus`
- Run mode: `typical_synth`
- Git HEAD: `d79091b413d528ecd75d5cc5390e2ab7341b1219`
- Genus exit code: 0
- Snapshot exit code: 0
- Signoff status: `TYPICAL_ONLY_NOT_MMMC_NOT_FINAL_SIGNOFF`
- Frequency mode: `r750_delta5`
- Packet format: unchanged
- NFAST encoding: `raw_lfsr_tag`
- Phase buffer topology: `one BUHDX4 per tap`
- HDL filelist: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/filelist_o12_phase_isolation.f`
- SDC overlay: `/home/validmgr/ksabra/2026_SPAD/SPADMIC/MPTDC/syn/inputs/mptdc_osc_typical_r750_delta5_o12_phase_buffers.sdc`
- RO_tune4 instance count: 2
- mptdc_osc_stub residue count: 0
- BUHDX4 phase-buffer instance count: 46
- phase-buffer hierarchy text count: 3
- report_clocks RO_tune4/S match count: 16
- report_clocks buffer generated-clock count: 0

O12_STATUS=O12_NETLIST_CANDIDATE
FINAL_SIGNOFF=NO
INNOVUS_READY=RUN_O12_LOAD_FEASIBILITY_AFTER_REVIEW

## Key Files
- present: `genus_20260608_o12_phase_isolation_genus.log`
- present: `mptdc_top_asic.postsyn.v`
- present: `mptdc_top_asic.postsyn.sdc`
- present: `final_sdc_overlay_used.sdc`
- present: `final_filelist_used.f`
- present: `o12_phase_isolation_check.rpt`
- present: `run_manifest.txt`
- present: `report_clocks.rpt`
- present: `report_design_rules.rpt`
- present: `report_high_fanout.rpt`
- present: `timing_summary.rpt`
- present: `timing_violations.rpt`
- present: `timing_pd_capture_hotspots.rpt`
- present: `timing_clk_sys_violations.rpt`
