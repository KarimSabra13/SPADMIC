#######################################################
#                                                     
#  Innovus Command Logging File                     
#  Created on Mon Jun  8 14:34:58 2026                
#                                                     
#######################################################

#@(#)CDS: Innovus v22.33-s094_1 (64bit) 08/25/2023 16:48 (Linux 3.10.0-693.el7.x86_64)
#@(#)CDS: NanoRoute 22.33-s094_1 NR230808-0153/22_13-UB (database version 18.20.615_1) {superthreading v2.20}
#@(#)CDS: AAE 22.13-s029 (64bit) 08/25/2023 (Linux 3.10.0-693.el7.x86_64)
#@(#)CDS: CTE 22.13-s030_1 () Aug 22 2023 02:51:11 ( )
#@(#)CDS: SYNTECH 22.13-s015_1 () Aug 20 2023 22:21:55 ( )
#@(#)CDS: CPE v22.13-s082
#@(#)CDS: IQuantus/TQuantus 21.2.2-s211 (64bit) Tue Jun 20 22:12:10 PDT 2023 (Linux 3.10.0-693.el7.x86_64)

set_global _enable_mmmc_by_default_flow      $CTE::mmmc_default
suppressMessage ENCEXT-2799
getVersion
getVersion
getVersion
restoreDesign /home/validmgr/ksabra/2026_SPAD/SPADMIC/results/innovus/20260608_o12_phase_buffer_pnr_abs1/checkpoints/04_route.enc.dat mptdc_top_asic
report_clocks > "/home/validmgr/ksabra/2026_SPAD/SPADMIC/results/innovus/20260608_o12_phase_buffer_analysis_abs2/reports/report_clocks.rpt"
report_constraint -max_capacitance -all_violators > /home/validmgr/ksabra/2026_SPAD/SPADMIC/results/innovus/20260608_o12_phase_buffer_analysis_abs2/reports/drv_max_cap.rpt
set enc_check_rename_command_name 1
