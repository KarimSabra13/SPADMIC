# O12 Phase Buffer Balance Summary

REPORT_STATUS=REVIEW_REQUIRED

- Source run: `20260608_o12_phase_buffer_pnr_abs1`
- Strict analog D-load budget: `58.72 fF` (`0.05872 pF`).
- CN/clock-like estimate: `75.59 fF` (`0.07559 pF`).
- RO Liberty shell max-cap bound: `50.00 fF` (`0.050 pF`).
- Raw RO rows: 16.
- Matched raw RO rows: 16.
- Missing raw RO rows: 0.
- Raw rows bounded by no max-cap violation: 16.
- Buffer output rows: 16.
- Matched buffer output rows: 16.
- Missing buffer output rows: 0.
- Max measured raw RO source load: no violating raw RO pin in `drv_max_cap.rpt`; raw rows are bounded by the 50 fF RO shell max-cap where matched.
- Max measured buffer output load violation: none found in `drv_max_cap.rpt`.

## Raw RO Budget Labels

| Label | Row count |
|---|---:|
| OK_STRICT | 16 |
| OK_CN | 0 |
| WARN_OVER_CN | 0 |
| FAIL_HIGH_LOAD | 0 |
| CRITICAL | 0 |
| UNKNOWN | 0 |

## Buffer Output Labels

| Label | Row count |
|---|---:|
| OK_STRICT | 0 |
| OK_CN | 0 |
| WARN_OVER_CN | 0 |
| FAIL_HIGH_LOAD | 0 |
| CRITICAL | 0 |
| UNKNOWN | 16 |

Required CSVs:

- `ro_phase_raw_pin_loads.csv`
- `phase_buffer_output_loads.csv`

This is an O12 feasibility report, not signoff.  Passing raw RO rows mean the direct RO load is isolated; buffer output load still needs timing, balance, placement, and power review.
