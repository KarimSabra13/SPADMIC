# O12 Phase Buffer Load Analysis Summary

REPORT_STATUS=REVIEW_REQUIRED

- Run ID: `20260608_o12_phase_buffer_analysis_abs2`
- Source run: `20260608_o12_phase_buffer_pnr_abs1`
- Mode: report-only restore of an O12 routed checkpoint.
- No routing, CTS, RTL, SDC, or Liberty relaxation is performed by this run.
- Main load report: `phase_buffer_balance_summary.md`.
- CSVs: `ro_phase_raw_pin_loads.csv`, `phase_buffer_output_loads.csv`.
- Labels: `O12_PHASE_ISOLATION_BUFFER_EXPERIMENT`, `REPORT_ONLY`, `NOT_FINAL_SIGNOFF`.
