# O12 Phase Buffer Load Analysis Wrapper Summary

- Run ID: `20260608_o12_phase_buffer_analysis_abs2`
- Run mode: `report_only`
- Source run ID: `20260608_o12_phase_buffer_pnr_abs1`
- Git HEAD: `105c531f8818865f30b0f93f4ffdcea34e710024`
- Innovus exit code: 0
- Required outputs exit code: 0
- Wrapper exit code: 0
- REPORT_COMPLETE: `YES`
- Result directory: `results/innovus/20260608_o12_phase_buffer_analysis_abs2`
- Labels: `O12_PHASE_ISOLATION_BUFFER_EXPERIMENT`, `REPORT_ONLY`, `NOT_FINAL_SIGNOFF`

## Key Outputs
- present: `reports/SUMMARY.md`
- present: `reports/report_clocks.rpt`
- present: `reports/drv_max_cap.rpt`
- present: `reports/ro_phase_raw_pin_loads.csv`
- present: `reports/phase_buffer_output_loads.csv`
- present: `reports/phase_buffer_balance_summary.md`
- present: `reports/phase_net_load_budget_summary.md`
