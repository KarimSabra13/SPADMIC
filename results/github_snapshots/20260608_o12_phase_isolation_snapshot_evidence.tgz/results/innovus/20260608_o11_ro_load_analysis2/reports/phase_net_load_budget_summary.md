# O11 RO Phase Load Budget Summary

REPORT_STATUS=REVIEW_REQUIRED

- Source run: `20260604_o10_2_pnr_repair`
- Source pins: exact `u_core/u_osc_*/u_ro_tune4/S[n]` and `u_core_u_osc_*_u_ro_tune4/S[n]` aliases; nets are derived from matched pins.
- Strict analog D-load budget: `58.72 fF` (`0.05872 pF`).
- CN/clock-like estimate: `75.59 fF` (`0.07559 pF`).
- Budget labels: `OK_STRICT <= 58.72 fF`, `OK_CN <= 75.59 fF`, `WARN_OVER_CN <= 150 fF`, `FAIL_HIGH_LOAD > 150 fF and <= 300 fF`, `CRITICAL > 300 fF`.
- Total RO phase rows: 16.
- Matched source-pin rows: 16.
- Rows without source-pin match: 0.
- Rows without net from source pin: 0.
- Max measured source-pin net load: `718.00 fF` at `fast S[4] u_core_u_osc_fast_u_ro_tune4/S[4]`.

| Label | Row count |
|---|---:|
| OK_STRICT | 0 |
| OK_CN | 0 |
| WARN_OVER_CN | 0 |
| FAIL_HIGH_LOAD | 0 |
| CRITICAL | 9 |
| UNKNOWN | 7 |

Required CSVs:

- `phase_net_loads.csv`
- `fast_tag_loads.csv`
- `ro_phase_sink_classification.csv`

This report does not waive RO_tune4 output loading.  It classifies the physical load so the next backend or analog decision can be made from the real sinks.
